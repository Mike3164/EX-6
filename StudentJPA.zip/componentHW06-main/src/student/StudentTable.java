package student;
import student.Student;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;


public class StudentTable {
    public static void insertStudent(Student emp) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("StudentDB");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        try {
            em.persist(emp);
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            em.getTransaction().rollback();
        } finally {
            em.close();
        }
    }
    public static void updateStudent(Student emp) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("StudentDB");
        EntityManager em = emf.createEntityManager();
        Student fromDb = em.find(Student.class, emp.getId());
        fromDb.setName(emp.getName());
        fromDb.setGpa(emp.getGpa());
        em.getTransaction().begin();
        try {
            em.persist(fromDb);
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            em.getTransaction().rollback();
        } finally {
            em.close();
        }
    }
    public static void removeStudent(Student emp) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("StudentDB");
        EntityManager em = emf.createEntityManager();
        Student fromDb = em.find(Student.class, emp.getId());
        em.getTransaction().begin();
        try {
            em.remove(fromDb);
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            em.getTransaction().rollback();
        } finally {
            em.close();
        }
                
    }
    
}
